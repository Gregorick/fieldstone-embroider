:HL["/fieldstone-embroider/_next/static/chunks/455457ccbc1b9099.css","style"]
:HL["/fieldstone-embroider/_next/static/media/83afe278b6a6bb3c-s.p.3a6ba036.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/fieldstone-embroider/_next/static/chunks/7f68d630bd207d5f.css","style"]
0:{"buildId":"_lbnVOwDGdh4tNUrR34HE","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
