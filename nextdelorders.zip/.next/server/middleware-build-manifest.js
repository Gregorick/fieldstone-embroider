globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/1d622e6ea9cfddc7.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/e79c7a36c9438eb3.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/turbopack-eb6d1d7aff724415.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];