module.exports=[98681,a=>{"use strict";var b=a.i(57316);a.s([],34267),a.i(34267),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],98681)}];

//# sourceMappingURL=_next-internal_server_app_register_page_actions_ef98effb.js.map