module.exports=[30723,a=>{"use strict";var b=a.i(57316);a.s([],48404),a.i(48404),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],30723)}];

//# sourceMappingURL=_next-internal_server_app_test-sanmar_page_actions_329208fd.js.map