module.exports=[6077,a=>{"use strict";var b=a.i(57316);a.s([],40597),a.i(40597),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],6077)}];

//# sourceMappingURL=_next-internal_server_app_about_page_actions_37873ece.js.map