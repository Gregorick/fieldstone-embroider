module.exports=[71124,a=>{"use strict";var b=a.i(57316);a.s([],24377),a.i(24377),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],71124)}];

//# sourceMappingURL=_next-internal_server_app_products_page_actions_9e1ae422.js.map