module.exports=[72944,a=>{"use strict";var b=a.i(57316);a.s([],61630),a.i(61630),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],72944)}];

//# sourceMappingURL=_next-internal_server_app_return-policy_page_actions_c1bb54b4.js.map