module.exports=[64585,a=>{"use strict";var b=a.i(57316);a.s([],25889),a.i(25889),a.s(["405fef94783914da98ab02f8b838979ee96d8a3002",()=>b.getLiveInventory],64585)}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bslug%5D_page_actions_6991d86a.js.map