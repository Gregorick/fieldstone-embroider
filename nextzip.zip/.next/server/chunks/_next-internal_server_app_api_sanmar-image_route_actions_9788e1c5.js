module.exports=[47468,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sanmar-image_route_actions_9788e1c5.js.map