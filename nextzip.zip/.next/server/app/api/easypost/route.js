var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/easypost/route.js")
R.c("server/chunks/[root-of-the-server]__96a5a08e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_easypost_route_actions_f81d397b.js")
R.m(20106)
module.exports=R.m(20106).exports
