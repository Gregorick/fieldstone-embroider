var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/clover/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/node_modules_0dd28b69._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_webhooks_clover_route_actions_409de717.js")
R.m(77418)
module.exports=R.m(77418).exports
