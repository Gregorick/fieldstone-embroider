var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/verify-address/route.js")
R.c("server/chunks/[root-of-the-server]__77e49aee._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_verify-address_route_actions_7c7042a5.js")
R.m(40601)
module.exports=R.m(40601).exports
