module.exports=[12555,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin-data_route_actions_133bb7df.js.map