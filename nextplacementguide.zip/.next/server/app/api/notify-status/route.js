var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notify-status/route.js")
R.c("server/chunks/[root-of-the-server]__6bfceb41._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_f899a2df._.js")
R.c("server/chunks/_next-internal_server_app_api_notify-status_route_actions_d8783209.js")
R.m(25051)
module.exports=R.m(25051).exports
