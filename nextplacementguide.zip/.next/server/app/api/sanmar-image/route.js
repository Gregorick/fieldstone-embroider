var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sanmar-image/route.js")
R.c("server/chunks/[root-of-the-server]__44b31066._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_sanmar-image_route_actions_9788e1c5.js")
R.m(17295)
module.exports=R.m(17295).exports
