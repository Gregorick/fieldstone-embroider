var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create-checkout/route.js")
R.c("server/chunks/[root-of-the-server]__37d77106._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_create-checkout_route_actions_1b66b08c.js")
R.m(34865)
module.exports=R.m(34865).exports
