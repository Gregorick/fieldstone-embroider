var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create-stripe-checkout/route.js")
R.c("server/chunks/[root-of-the-server]__2dda5555._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__4e09f89d._.js")
R.c("server/chunks/_next-internal_server_app_api_create-stripe-checkout_route_actions_9178d157.js")
R.m(8636)
module.exports=R.m(8636).exports
