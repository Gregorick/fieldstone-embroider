var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admin-data/route.js")
R.c("server/chunks/[root-of-the-server]__34cdfd4c._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin-data_route_actions_133bb7df.js")
R.m(11954)
module.exports=R.m(11954).exports
