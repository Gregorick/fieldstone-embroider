var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-quote/route.js")
R.c("server/chunks/[root-of-the-server]__77b02be7._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_f899a2df._.js")
R.c("server/chunks/_next-internal_server_app_api_send-quote_route_actions_95cc7311.js")
R.m(65765)
module.exports=R.m(65765).exports
