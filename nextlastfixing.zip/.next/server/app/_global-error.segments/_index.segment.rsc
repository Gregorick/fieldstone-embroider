1:"$Sreact.fragment"
2:I[39756,["/fieldstone-embroider/_next/static/chunks/ff1a16fafef87110.js","/fieldstone-embroider/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
3:I[37457,["/fieldstone-embroider/_next/static/chunks/ff1a16fafef87110.js","/fieldstone-embroider/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"HdzoFlr6-RdrIiQuxKs9T","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
