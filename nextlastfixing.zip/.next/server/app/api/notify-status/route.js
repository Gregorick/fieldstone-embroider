var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notify-status/route.js")
R.c("server/chunks/[root-of-the-server]__9b9c56b9._.js")
R.c("server/chunks/node_modules_f899a2df._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_notify-status_route_actions_d8783209.js")
R.m(27303)
module.exports=R.m(27303).exports
