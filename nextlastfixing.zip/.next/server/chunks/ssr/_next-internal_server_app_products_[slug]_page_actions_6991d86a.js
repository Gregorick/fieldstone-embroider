module.exports=[64585,a=>{"use strict";var b=a.i(57316);a.s([],25889),a.i(25889),a.s(["40619f1c15f2b20a45e42d9b8e8eab2e195df6e073",()=>b.getLiveInventory],64585)}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bslug%5D_page_actions_6991d86a.js.map