module.exports=[6077,a=>{"use strict";var b=a.i(57316);a.s([],40597),a.i(40597),a.s(["40619f1c15f2b20a45e42d9b8e8eab2e195df6e073",()=>b.getLiveInventory],6077)}];

//# sourceMappingURL=_next-internal_server_app_about_page_actions_37873ece.js.map