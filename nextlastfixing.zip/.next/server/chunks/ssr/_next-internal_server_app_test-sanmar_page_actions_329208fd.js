module.exports=[30723,a=>{"use strict";var b=a.i(57316);a.s([],48404),a.i(48404),a.s(["40619f1c15f2b20a45e42d9b8e8eab2e195df6e073",()=>b.getLiveInventory],30723)}];

//# sourceMappingURL=_next-internal_server_app_test-sanmar_page_actions_329208fd.js.map