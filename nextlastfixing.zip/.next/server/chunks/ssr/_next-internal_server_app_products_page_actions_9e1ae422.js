module.exports=[71124,a=>{"use strict";var b=a.i(57316);a.s([],24377),a.i(24377),a.s(["40619f1c15f2b20a45e42d9b8e8eab2e195df6e073",()=>b.getLiveInventory],71124)}];

//# sourceMappingURL=_next-internal_server_app_products_page_actions_9e1ae422.js.map