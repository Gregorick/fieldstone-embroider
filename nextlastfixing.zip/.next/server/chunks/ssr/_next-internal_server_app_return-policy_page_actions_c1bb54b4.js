module.exports=[72944,a=>{"use strict";var b=a.i(57316);a.s([],61630),a.i(61630),a.s(["40619f1c15f2b20a45e42d9b8e8eab2e195df6e073",()=>b.getLiveInventory],72944)}];

//# sourceMappingURL=_next-internal_server_app_return-policy_page_actions_c1bb54b4.js.map